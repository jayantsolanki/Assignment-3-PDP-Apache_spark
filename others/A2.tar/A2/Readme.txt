/*
* Took references from:
*	1 - https://www.linkedin.com/pulse/connected-component-using-map-reduce-apache-spark-shirish-kumar
*	2 - http://mmds-data.org/presentations/2014/vassilvitskii_mmds14.pdf
*	Please check the build.sbt file for scala version check before proceeding to execute this file
*	Output graph is written inside the output folder at same directory level
*	Do delete the output folder using make clean before proceeding to execute
*	Build system is provided, just type make demo to run the code on given input.txt file
*/
